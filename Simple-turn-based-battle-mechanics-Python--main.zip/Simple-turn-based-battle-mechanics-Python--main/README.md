# Simple-turn-based-battle-mechanics-Python-
This turn-based battle mechanic made in python is designed to be understood by any degree of python understanding. It is a little messy, but it is super simple. Feel free to copy and change the code however you like!
